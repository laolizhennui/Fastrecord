#include <stdio.h>
#include <string.h>
#include <windows.h>
#include <stdlib.h>
#include <time.h>
#define MAX_CHAR_LEN 10
#define MAX_FILE_PATH 256

void Screen_recording(char filePath[MAX_FILE_PATH], const char *encoding, const char *frames, const char *bitrate, int screenWidth, int screenHeight)
{
    // 获取当前时间戳作为文件名
    time_t rawtime;
    struct tm *timeinfo;
    char timestamp[20];

    time(&rawtime);
    timeinfo = localtime(&rawtime);
    strftime(timestamp, sizeof(timestamp), "%Y%m%d_%H%M%S", timeinfo);

    // 创建输出文件路径
    char outputPath[MAX_FILE_PATH];
    snprintf(outputPath, sizeof(outputPath), "%s%s.mp4", filePath, timestamp);

    // 根据分辨率设置视频大小，增加码率设置
    char command[400];
    snprintf(command, sizeof(command), "ffmpeg\\ffmpeg -video_size %dx%d -framerate %s -f gdigrab -i desktop -c:v %s -b:v %s -preset ultrafast -pix_fmt yuv420p %s", screenWidth, screenHeight, frames, encoding, bitrate, outputPath);

    // 获取当前控制台窗口的句柄
    HWND hWnd = GetConsoleWindow();
    // 最小化窗口
    ShowWindow(hWnd, SW_MINIMIZE);

    // 执行录屏命令
    system(command);
}

void printVersion()
{
    puts("Fastrecord 1.0\n作者：我不精通C语言，bilibili主页：https://space.bilibili.com/3493104185248298\n如果有任何问题请报告给QAse123452022@163.com。");
}

void open(char *filePath)
{
    char command[284] = "ffmpeg\\ffplay ";
    strcat(command, filePath);
    system(command);
}

int main(int argc, char *argv[])
{
    if (argc > 1)
    {
        open(argv[1]);
        return 0;
    }
    SetConsoleTitle("Fastrecord");
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
    puts("欢迎使用Fastrecord");
    
    // 读取配置文件
    char filePath[MAX_FILE_PATH];
    FILE *fp = fopen("config.ini", "r");
    if (fp == NULL)
    {
        puts("没有找到配置文件，请重新安装软件。");
        system("pause");
        return 0;
    }
    
    char encoding[MAX_CHAR_LEN] = "libx265"; // 默认编码
    char path[MAX_FILE_PATH] = "./";         // 默认路径
    char frames[MAX_CHAR_LEN] = "30";        // 默认帧数
    int screenWidth = 1920;                  // 默认屏幕宽度
    int screenHeight = 1080;                 // 默认屏幕高度
    char bitrate[MAX_CHAR_LEN] = "4000k";    // 默认码率
    int i = 0;

    while (fgets(filePath, sizeof(filePath), fp) != NULL)
    {
        filePath[strcspn(filePath, "\n")] = 0; // 去掉换行符
        if (strcmp(filePath, "") == 0)
        {
            continue;
        }
        else
        {
            switch (i)
            {
            case 0:
                // 录屏文件编码
                strncpy(encoding, filePath, sizeof(encoding) - 1);
                encoding[sizeof(encoding) - 1] = '\0'; // 确保字符串结尾
                break;
            case 1:
                // 录屏文件路径
                strncpy(path, filePath, sizeof(path) - 1);
                path[sizeof(path) - 1] = '\0'; // 确保字符串结尾
                break;
            case 2:
                // 帧数
                strncpy(frames, filePath, sizeof(frames) - 1);
                frames[sizeof(frames) - 1] = '\0'; // 确保字符串结尾
                break;
            case 3:
                // 屏幕宽度
                screenWidth = atoi(filePath);
                break;
            case 4:
                // 屏幕高度
                screenHeight = atoi(filePath);
                break;
            case 5:
                // 码率
                strncpy(bitrate, filePath, sizeof(bitrate) - 1);
                bitrate[sizeof(bitrate) - 1] = '\0'; // 确保字符串结尾
                break;
            }
            i++;
        }
    }
    fclose(fp);
    
    while (1)
    {
        puts("请选择功能：");
        puts("1.录屏\n2.关于\n3.播放");
        char command[MAX_CHAR_LEN];
        fgets(command, sizeof(command), stdin);
        command[strcspn(command, "\n")] = 0;
        if (strcmp(command, "") == 0)
        {
            continue;
        }
        switch (command[0])
        {
        case '1':
            puts("开始录屏...(Q键结束)");
            Screen_recording(path, encoding, frames, bitrate, screenWidth, screenHeight);
            puts("录屏结束。");
            break;
        case '2':
            printVersion();
            break;
        case '3':
            puts("请输入文件路径：");
            char playPath[MAX_FILE_PATH];
            fgets(playPath, sizeof(playPath), stdin);
            playPath[strcspn(playPath, "\n")] = 0;
            open(playPath);
            break;
        default:
            puts("无效的选择，请重试。");
            break;
        }
        system("pause");
        system("cls");
    }
    return 0;
}
